package com.enx.pipedrop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainMenu extends AppCompatActivity {

    private Button orificeCalcButton;
    private Button manualButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        orificeCalcButton = (Button) findViewById(R.id.orificeButton);
        orificeCalcButton.setOnClickListener(this::onOrificeClick);
        manualButton = (Button) findViewById(R.id.manualButton);
        manualButton.setOnClickListener(this::onManualClick);
    }

    private void onOrificeClick(View view) {
        Intent orificeClick = new Intent(MainMenu.this, MainActivity.class);
        startActivity(orificeClick);
    }

    private void onManualClick(View view) {
        Intent manualClick = new Intent(MainMenu.this, Manual.class);
        startActivity(manualClick);
    }
}